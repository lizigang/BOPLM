function net=PRN_configuration
% Create a Pattern Recognition Network

hiddenLayerSize = [20,20]; 
transfer_fcn_hiddenLayer={'tansig','tansig'};      
transfer_fcn_outLayer={'softmax'};                
transfer_fcn=[transfer_fcn_hiddenLayer,transfer_fcn_outLayer];  
net = patternnet(hiddenLayerSize);    
for k=1:net.numLayers
    net.layers{k}.transferFcn=transfer_fcn{k};
end    

net.trainFcn='trainlm';
net.performFcn='mse';   
net.divideFcn='dividerand';   
net.divideParam.trainRatio = 0.7;   % Ratio of vectors for training. Default = 0.7
net.divideParam.valRatio = 0.15;    % Ratio of vectors for validation. Default = 0.15
net.divideParam.testRatio = 0.15;   % Ratio of vectors for testing. Default = 0.15
net.divideMode='sample';

net.trainParam.epochs = 1000; % Maximum Epochs 
net.trainParam.time=Inf;  % Maximum Training Time in seconds
net.trainParam.goal=1e-6; % Performance Goal
net.trainParam.min_grad=1e-6;  % Minimum performance gradient
net.trainParam.max_fail=6;   % Maximum number of validation checks

net.trainParam.showWindow=0; % Show training GUI
net.trainParam.show=Inf;  % Command Line Frequency
if (isinf(net.trainParam.show))
    net.trainParam.showCommandLine=false; % Show Command Line Feedback
else
    net.trainParam.showCommandLine=true; 
end

