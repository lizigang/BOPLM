function [label,invalid_points]=labeling(fun_name,x0,SimNum,interval_lb,interval_ub,sim_method,num_label,kernel,fun_type)

D=size(x0,2);
switch sim_method
    case 'Serial'
        yend=eq_fun(x0,fun_name,fun_type);  %% Serial Computing
    case 'CPU_Parallel'
        NPB=250;  % SimNum per BlockNum
        BlockNum=ceil(SimNum/NPB);  % number of block that samples are divided into
        Y=cell(BlockNum,1);
        parfor i=1:BlockNum
            if i<BlockNum
                Y{i,1}=eq_fun(x0((i-1)*NPB+1:i*NPB,:),fun_name,fun_type);
            else
                Y{i,1}=eq_fun(x0((i-1)*NPB+1:end,:),fun_name,fun_type);
            end
        end
        yend=cell2mat(Y);
    case 'GPU_Parallel'
        ThreadsPerBlock=kernel.MaxThreadsPerBlock;
        if(SimNum<ThreadsPerBlock)
            ThreadsPerBlock=SimNum;
        end
        
        kernel.ThreadBlockSize = [ThreadsPerBlock,1,1];
        kernel.GridSize = [ceil(SimNum/kernel.MaxThreadsPerBlock),1];
        % setConstantMemory(ode4_kernel,'Dmax',int32(10));
        
        yend=x0';
        yend=yend(:);
        yend=feval(kernel,yend,SimNum,D);  % evaluated on GPU
        yend=gather(yend);
        yend=(reshape(yend,D,SimNum))';
end
%%%%%%%%%%%%%%%%
if(strcmp(fun_type,'basin of attration'))
    invalid_points=find(isnan(yend(:,1)));
    label=zeros(SimNum,1)*nan;
elseif(strcmp(fun_type,'zeros finding'))
    invalid_points=[];
    label=zeros(SimNum,1);
end

switch fun_name
    case 'ML' % the ML neurons System
        index1=(yend(:,1)<-0.25)&(yend(:,2)<-0.25);   
        label(index1,1)=1; 
        index2=(yend(:,1)>-0.25)&(yend(:,2)<-0.25);  
        label(index2,1)=2;     
        index3=(yend(:,1)<-0.25)&(yend(:,2)>-0.25); 
        label(index3,1)=3; 
        index4=(yend(:,1)>-0.25)&(yend(:,2)>-0.25);  
        label(index4,1)=4;
end
if(strcmp(fun_type,'basin of attration'))
    index0=zeros(SimNum,1);
    for k=1:D
        index0=or(index0,yend(:,k)<interval_lb(k)|yend(:,k)>interval_ub(k)); %% criterion to stick labels_0 for
    end
    label(index0,1)=num_label+1; 
end
