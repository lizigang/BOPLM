function X = rk4T(v,X,h,n)

% RK4   Runge-Kutta scheme of order 4 
%   performs n steps of the scheme for the vector field v
%   using stepsize h on each row of the matrix X
%   v maps an (m x d)-matrix to an (m x d)-matrix 

for i = 1:n
    k1 = v(X,(i-1)*h);
    k2 = v(X + h/2*k1,(i-1)*h+h/2);
    k3 = v(X + h/2*k2,(i-1)*h+h/2);
    k4 = v(X + h*k3,(i-1)*h+h);
    X = X + h*(k1 + 2*k2 + 2*k3 + k4)/6;
end