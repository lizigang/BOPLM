function mdl=train_model(mdl,Predict_Method,train_data,train_label,num_label,net_reset)

switch Predict_Method
    case 'KNN'   % k-nearest neighbor classifier
        BreakTies='smallest';
        NumNeighbors=5;
        Distance='seuclidean';
        DistanceWeight=@(d)d.^(-3);
        
        OptimizeHyperparameters='none';  %help fitcknn
        HyperparameterOptimizationOptions=struct('UseParallel',true,...
            'ShowPlots',false,...
            'Verbose',0);
        
        mdl=fitcknn(train_data,train_label,'BreakTies',BreakTies,'NumNeighbors',NumNeighbors,'Distance',Distance,'DistanceWeight',DistanceWeight,'OptimizeHyperparameters',OptimizeHyperparameters, 'HyperparameterOptimizationOptions',HyperparameterOptimizationOptions);   % KNN method
    case 'SVM'   % support vector machine
        mdl=fitcsvm(train_data, train_label);   
       
    case 'PRN'   %% pattern recognition network
        if(strcmp(net_reset,'yes'))
            %% net configuration
            mdl=PRN_configuration;    
            % view(net);
        end
        %% computing configuration
        opin=computing_performance([],'PRN');
        
        %% Train the Network
        train_data=train_data';
        labels_samples=setdiff(unique(train_label),num_label+1);
        if((length(labels_samples)<num_label))
            error('labels of samples is sufficient!!!')
        end
        
        train_label=full(ind2vec(train_label'));
        [mdl,~] = train(mdl,train_data,train_label,'useParallel',opin.useParallel,'useGPU',opin.useGPU,'reduction',opin.reduction,'CheckpointFile',opin.CheckpointFile,'CheckpointDelay',opin.CheckpointDelay);
        %% Check the Network
        check_net=0;
        draw_net=0;
        if(check_net)
            predict0 = mdl(train_data);
            [~,predict0] = max(predict0);
            [~,Train_label] = max(train_label);
            errors=gsubtract(Train_label,predict0);
            net_performance=perform(mdl,Train_label,predict0);
            train_accuracy = length(find(predict0==Train_label))/size(train_data,2);
            fprintf('net_performance=%s, train_accuracy=%s, ',num2str(net_performance),num2str(train_accuracy));
            if(draw_net)
                figure;ploterrhist(errors,'bins',20)
                figure;plottrainstate(tr)
                figure;plotperform(tr)
            end
        end
    case 'PNN'     %  probabilistic neural network
        spread=0.1;   % spread=0.1 by default.
        train_data=train_data';
        train_label=ind2vec(train_label');

        mdl = newpnn(train_data,train_label,spread);  % probabilistic neural network
        
    case 'RBEN'   % exact radial basis network
        spread=1;     %The larger spread is, the smoother the function approximation. Too large a spread means a lot of neurons are required to fit a fast-changing function. Too small a spread means many neurons are required to fit a smooth function, and the network might not generalize well.
        train_data=train_data';
        train_label=ind2vec(train_label');

        mdl = newrbe(train_data,train_label,spread);

    case 'RBN'
        spread=1;    % spread=1 by default. The larger spread is, the smoother the function approximation. Too large a spread means a lot of neurons are required to fit a fast-changing function. Too small a spread means many neurons are required to fit a smooth function, and the network might not generalize well
        goal=1e-6;  %Mean squared error goal
        MN=100;   %Maximum number of neurons
        DF=inf;  %Number of neurons to add between displays
        
        train_data=train_data';
        train_label=ind2vec(train_label');

        mdl = newrb(train_data,train_label,goal,spread,MN,DF);   %%(revised function 'newrb' to aviod show in the iteration)

    case 'GRNN'
        spread=0.1;     % The larger the spread, the smoother the function approximation. To fit data very closely, use a spread smaller than the typical distance between input vectors. To fit the data more smoothly, use a larger spread.
        train_data=train_data';
        train_label=ind2vec(train_label');

        mdl = newgrnn(train_data,train_label,spread); 
end 