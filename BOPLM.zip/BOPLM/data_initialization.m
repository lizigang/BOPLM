function [x0,SimNum,SimNum_per_cell]=data_initialization(region_property,NumSim,initial_RandomSamples,iter)

SimNum=NumSim(1);
limit_num_SimNum=NumSim(2);
SimNum_per_cell=NumSim(3);
max_SimNum_per_cell=NumSim(4);
min_SimNum_per_cell=NumSim(5);

cell_num=region_property{1};
seed_cell_num=region_property{2};
cell_h=region_property{3};
D=region_property{4};
subinterval_lb=region_property{5};
subinterval_ub=region_property{6};

if(strcmp(initial_RandomSamples,'no')&&~iter)
    cell_pointcoordinate=cell(D,1);
    for i=1:D
        cell_pointcoordinate{i}=linspace(subinterval_lb(i),subinterval_ub(i),cell_num(i)+1);  % coordinates of points divided in each dimension
    end
    if(D==4)
        [meshpoint_1,meshpoint_2,meshpoint_3,meshpoint_4]=ndgrid(cell_pointcoordinate{1}(2:end),cell_pointcoordinate{2}(2:end),cell_pointcoordinate{3}(2:end),cell_pointcoordinate{4}(2:end));  %%%
        meshpoint_ub=[meshpoint_1(:),meshpoint_2(:),meshpoint_3(:),meshpoint_4(:)];  %%%
    else
        error('please set a correct meshpoints!!!')
    end
    center_points=meshpoint_ub-0.5*cell_h;
    SimNum=SimNum_per_cell*seed_cell_num;

    x0=zeros(SimNum,D);
    for i=1:D
        x0_each=((center_points(:,i)-cell_h(i)/2)+cell_h(i).*rand(seed_cell_num,SimNum_per_cell))';
        x0(:,i)=x0_each(:);
    end
elseif(strcmp(initial_RandomSamples,'yes')&&~iter)
    mean_cellpoint=SimNum/seed_cell_num;
    disp(['initial mean number of samples that fall in each cell is ',num2str(mean_cellpoint)])
    if(mean_cellpoint<min_SimNum_per_cell)
        disp('NOTICE: SimNum May Be Too Less!!!')
        load chirp
        sound(y,Fs)
        pause(3);
    end
    x0=(subinterval_lb+(subinterval_ub-subinterval_lb).*rand(SimNum,D));
    fprintf('------------------------------------------------------------------------------------------------------------------------------------\n')
elseif(iter)
    if(SimNum_per_cell>max_SimNum_per_cell)
        SimNum_per_cell=max_SimNum_per_cell;
    elseif(SimNum_per_cell<min_SimNum_per_cell)
        SimNum_per_cell=min_SimNum_per_cell;
    end
    SimNum=SimNum_per_cell*seed_cell_num;
    if(SimNum>limit_num_SimNum)
        SimNum_per_cell=floor(limit_num_SimNum/seed_cell_num);
        SimNum=SimNum_per_cell*seed_cell_num;
        if(SimNum_per_cell<min_SimNum_per_cell)
            fprintf('num_sim=%s(%s), ',num2str(SimNum),num2str(SimNum_per_cell));
            SimNum=0;x0=0;
            fprintf('\nEither of "SimNum" and "min_SimNum_per_cell" reaches the limits!!!\nExit\n')
            return;
        end
    end

    center_points=region_property{7};
    x0=zeros(SimNum,D);
    for i=1:D
        x0_each=((center_points(:,i)-cell_h(i)/2)+cell_h(i).*rand(seed_cell_num,SimNum_per_cell))';
        x0(:,i)=x0_each(:);
    end
end