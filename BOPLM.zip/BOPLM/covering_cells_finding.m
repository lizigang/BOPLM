function [DD,n]=covering_cells_finding(point_cellsID,point_label,CoveringCells_kernel,method,D,fun_type)

[A,B]=unique(point_cellsID);
B=[B;length(point_label)+1];

switch method
    case 'Serial'
        if(strcmp(fun_type,'basin of attration'))
            AA=ones(length(A),1);
            for i=1:length(A)
                C=unique(point_label(B(i):B(i+1)-1));
                if (length(C)>1)
                    AA(i)=0;
                end
            end
        elseif(strcmp(fun_type,'zeros finding'))
            AA=zeros(length(A),1);
            for i=1:length(A)
                C=point_label(B(i):B(i+1)-1)-1;
                for j=1:D
                    C_int=floor(C./2);
                    C2=C-C_int*2;
                    C=C_int;   
                    if(length(unique(C2))==2)
                        AA(i)=AA(i)+1;
                        continue;
                    elseif(length(unique(C2))<2)
                        AA(i)=0;
                        break;
                    end               
                end
                if(AA(i)==0)
                    AA(i)=1;
                elseif(AA(i)==D)
                    AA(i)=0;
                end
            end
        end

    case 'CPU_Parallel'
        if(strcmp(fun_type,'basin of attration'))
            AA=ones(length(A),1);
            parfor i=1:length(A)
                C=unique(point_label(B(i):B(i+1)-1));
                if (length(C)>1)
                    AA(i)=0;
                end
            end
        elseif(strcmp(fun_type,'zeros finding'))
            AA=zeros(length(A),1);
            parfor i=1:length(A)
                C=point_label(B(i):B(i+1)-1)-1;
                for j=1:D
                    C_int=floor(C./2);
                    C2=C-C_int*2;
                    C=C_int;   
                    if(length(unique(C2))==2)
                        AA(i)=AA(i)+1;
                        continue;
                    elseif(length(unique(C2))<2)
                        AA(i)=0;
                        break;
                    end               
                end
                if(AA(i)==0)
                    AA(i)=1;
                elseif(AA(i)==D)
                    AA(i)=0;
                end
            end
        end

    case 'GPU_Parallel'
        ThreadsPerBlock=CoveringCells_kernel.MaxThreadsPerBlock;
        if(length(A)<ThreadsPerBlock)
            ThreadsPerBlock=length(A);
        end
        CoveringCells_kernel.ThreadBlockSize = [ThreadsPerBlock,1,1];
        CoveringCells_kernel.GridSize = [ceil(length(A)/CoveringCells_kernel.MaxThreadsPerBlock),1];
        if(strcmp(fun_type,'basin of attration'))
            AA=feval(CoveringCells_kernel,A,B,point_label,length(A),D,1);  % evaluated on GPU
        elseif(strcmp(fun_type,'zeros finding'))
            AA=feval(CoveringCells_kernel,A,B,point_label,length(A),D,2);  % evaluated on GPU
        end
        AA=gather(AA);
end
index=find(AA==0);
n=length(index);
DD=A(index);
