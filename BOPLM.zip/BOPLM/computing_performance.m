function computing_options=computing_performance(sim_method,index)

switch index
    case 'Global'
        if(strcmp(sim_method,'CPU_Parallel'))
            poolobj = gcp;
            ode4_kernel=0;
            CoveringCells_kernel=0;
            Zerosfinding_kernel=0;
            fprintf('Simulations are simultaneously executed on CPU with %s workers.\n',num2str(poolobj.NumWorkers));
        elseif(strcmp(sim_method,'GPU_Parallel'))
            gpucount=gpuDeviceCount("available");
            %     gpuDeviceTable %check Supported GPUs by Release on %"https://ww2.mathworks.cn/help/parallel-computing/gpu-support-by-release.html"
            if(gpucount>0)
                gpuproperty=gpuDevice(1);
                [status,cmdout] = system('nvcc -ptx FindingBoundarygpu.cu');
                cudaFilename = 'FindingBoundarygpu.cu'; % Note: recompile the .ptx file if any changed in the file.
                ptxFilename = 'FindingBoundarygpu.ptx';
                if(~status)
                    ode4_kernel = parallel.gpu.CUDAKernel(ptxFilename, cudaFilename,'ODE4');
                    CoveringCells_kernel = parallel.gpu.CUDAKernel(ptxFilename, cudaFilename,'CoveringCellsgpu');
                    Zerosfinding_kernel = parallel.gpu.CUDAKernel(ptxFilename, cudaFilename,'Zerosfinding');  
                else
                    fprintf('%s',cmdout);
                    error('building file "FindingBoundarygpu.ptx" -- FAILED!!!')
                end
                fprintf('Simulations are simultaneously executed on "%s" GPU.\n',num2str(gpuproperty.Name));
            else
                error('GPU device is not available!!!')
            end
        elseif(strcmp(sim_method,'Serial'))
            fprintf('Simulations are serially executed on CPU.\n');
            ode4_kernel=0;
            CoveringCells_kernel=0;
            Zerosfinding_kernel=0;
        end
        computing_options=[ode4_kernel;CoveringCells_kernel;Zerosfinding_kernel];
        
    case 'PRN'
        % Parallel training is currently supported for backpropagation training only, not for self-organizing maps.  help train for detail
        Parallel='no';   % "yes" for training on different unique GPU devices or CPU workers, "no" for training in sequence
        On_GPU='yes';   % "yes" for parallel training on GPU (more devices when Parallel is "yes"), "no" for training on CPU, 'only' for parallel training on GPU only
        Memory_reduction=1;  % If MATLAB is being used and memory is an issue, setting the reduction option to a value N greater than 1, reduces much of the temporary storage required to train by a factor of N, in exchange for longer training times.
        Checkpoint_filename=''; % Checkpoint Saves
        Checkpoint_delay=120;  
        computing_options=struct('useParallel',Parallel,'useGPU',On_GPU,'reduction',Memory_reduction,'CheckpointFile',Checkpoint_filename,'CheckpointDelay',Checkpoint_delay);
end