function plots_fun(data,draw_range,draw_coor,num_label,index)
switch index
    case 1
        cl=[0,0,1;1,0,0];
        if(num_label>2)
            cl=colormap(jet(num_label));
        end
        drwa_D=size(draw_coor,2);
        train_data=data{1,1};
        train_label=data{2,1};
        predict_data=data{3,1};
        predict_label=data{4,1};
        test_label=data{5,1};
        hold on;box on;grid on;
        if(drwa_D==2)
            for k=1:num_label
                plot(train_data(train_label==k,draw_coor(1)),train_data(train_label==k,draw_coor(2)),'.','color',cl(k,:),'markersize',5)
            end
            if(~isempty(test_label))
                plot(predict_data(predict_label~=test_label,draw_coor(1)),predict_data(predict_label~=test_label,draw_coor(2)),'ko','markersize',8)
            end
            xlabel('X_1');ylabel('X_2');
            xlim(draw_range(draw_coor(1),:));ylim(draw_range(draw_coor(2),:));
        elseif(drwa_D>2)
            for k=1:num_label
                plot3(train_data(train_label==k,draw_coor(1)),train_data(train_label==k,draw_coor(2)),train_data(train_label==k,draw_coor(3)),'.','color',cl(k,:),'markersize',5)
            end
            if(~isempty(test_label))
                plot3(predict_data(predict_label~=test_label,draw_coor(1)),predict_data(predict_label~=test_label,draw_coor(2)),predict_data(predict_label~=test_label,draw_coor(3)),'ko','markersize',8)
            end
            view([45,-45,45]);xlabel('X_1');ylabel('X_2');zlabel('X_3');
            xlim(draw_range(draw_coor(1),:));ylim(draw_range(draw_coor(2),:));zlim(draw_range(draw_coor(3),:));
        end
        drawnow;
        
    case 2
        drwa_D=size(draw_coor,2);
        hold on;box on;grid on;
        if(drwa_D==2)
            plot(data(:,draw_coor(1)),data(:,draw_coor(2)),'m*','markersize',8)
            xlabel('X_1');ylabel('X_2');
            xlim(draw_range(draw_coor(1),:));ylim(draw_range(draw_coor(2),:));
        elseif(drwa_D>2)
            plot3(data(:,draw_coor(1)),data(:,draw_coor(2)),data(:,draw_coor(3)),'m*','markersize',8)
            view([45,-45,45]);xlabel('X_1');ylabel('X_2');zlabel('X_3');
            xlim(draw_range(draw_coor(1),:));ylim(draw_range(draw_coor(2),:));zlim(draw_range(draw_coor(3),:));
        end
        drawnow;
end